extern GLuint LoadGLTexture( const char *filename );			// Load Bitmaps And Convert To Textures

